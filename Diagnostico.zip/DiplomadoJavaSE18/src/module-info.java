module DiplomadoJavaSE18 {
	requires java.desktop;
}